# LaTeX-версия отчёта

Файлы: `REPORT.tex` (основной), `header.tex` (оформление), `figures/` (графики).

Сборка: XeLaTeX, два прохода (для оглавления):

    xelatex REPORT.tex && xelatex REPORT.tex

Overleaf: New Project, Upload Project, этот zip; затем Menu, Compiler: **XeLaTeX**, Recompile.

Таблицы с цифрами в .tex являются снимком результатов. Основной источник отчёта: `reports/REPORT_template.md` (таблицы подставляются из `results/*.csv` скриптом `scripts/render_report.py`); после пересчёта результатов LaTeX пересобирается командой `python scripts/build_latex.py`.
